const config = {
    "name": "config.js"
    , "dbName": "save-anywhere"
    , "dbDesc": "save-anywhere database"
    , "dbDataTableName": "notes"

    , "operationDelayMs": 500
};

export default config;


import IndexDB from './db/IndexDB.js'

let DB = new IndexDB();

export default DB;
